listaClientes = []
clientes = 0
costos = 0


while clientes < 1214755241:
    cliente = input("Nombre del cliente: ")
    producto = input("Producto que recibe: ")
    costo = float(input("Costo monetario del producto($0.00): "))
    costos += costo

    registro = dict(cliente=cliente, producto=producto, costo=costo)
    listaClientes.append(registro)

    final = input("¿Desea agregar más datos? Responder Si o No")
    if final == ("Si"):
        clientes += 1
    else:
        break


for registro in listaClientes:
    print(registro)

print(costos)